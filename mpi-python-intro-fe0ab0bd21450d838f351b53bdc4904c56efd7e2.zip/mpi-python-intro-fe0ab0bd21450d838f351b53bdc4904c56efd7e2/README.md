# Introduction to Python
Welcome to the IMPRS course Introduction to Python.
To access the lecture notes and homework assignments, please clone this repository.
To submit your homework, create a branch named after yourself, create local commits and then push your completed assignment back to us.
